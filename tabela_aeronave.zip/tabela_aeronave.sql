-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.1.35-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura para tabela aeronave.aeronave
CREATE TABLE IF NOT EXISTS `aeronave` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prefixo` varchar(50) NOT NULL,
  `tipo` enum('P','C') NOT NULL,
  `horas_voo` varchar(50) NOT NULL,
  `ano_fabricacao` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.aeronave: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `aeronave` DISABLE KEYS */;
INSERT INTO `aeronave` (`id`, `prefixo`, `tipo`, `horas_voo`, `ano_fabricacao`) VALUES
	(9, 'teste', 'P', '12:31:23', '1998-10-23'),
	(10, 'aeronave1', 'C', '12:32:13', '1970-01-01');
/*!40000 ALTER TABLE `aeronave` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.estado
CREATE TABLE IF NOT EXISTS `estado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(75) DEFAULT NULL,
  `uf` varchar(5) DEFAULT NULL,
  `pais` int(7) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Estado_pais` (`pais`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.estado: ~27 rows (aproximadamente)
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
INSERT INTO `estado` (`id`, `nome`, `uf`, `pais`) VALUES
	(1, 'Acre', 'AC', 1),
	(2, 'Alagoas', 'AL', 1),
	(3, 'Amazonas', 'AM', 1),
	(4, 'Amapá', 'AP', 1),
	(5, 'Bahia', 'BA', 1),
	(6, 'Ceará', 'CE', 1),
	(7, 'Distrito Federal', 'DF', 1),
	(8, 'Espírito Santo', 'ES', 1),
	(9, 'Goiás', 'GO', 1),
	(10, 'Maranhão', 'MA', 1),
	(11, 'Minas Gerais', 'MG', 1),
	(12, 'Mato Grosso do Sul', 'MS', 1),
	(13, 'Mato Grosso', 'MT', 1),
	(14, 'Pará', 'PA', 1),
	(15, 'Paraíba', 'PB', 1),
	(16, 'Pernambuco', 'PE', 1),
	(17, 'Piauí', 'PI', 1),
	(18, 'Paraná', 'PR', 1),
	(19, 'Rio de Janeiro', 'RJ', 1),
	(20, 'Rio Grande do Norte', 'RN', 1),
	(21, 'Rondônia', 'RO', 1),
	(22, 'Roraima', 'RR', 1),
	(23, 'Rio Grande do Sul', 'RS', 1),
	(24, 'Santa Catarina', 'SC', 1),
	(25, 'Sergipe', 'SE', 1),
	(26, 'São Paulo', 'SP', 1),
	(27, 'Tocantins', 'TO', 1);
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.login
CREATE TABLE IF NOT EXISTS `login` (
  `ind` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  PRIMARY KEY (`ind`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.login: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`ind`, `nome`, `email`, `password`) VALUES
	(10, 'admin', 'adm@teste.com', '4f22a5b713259a8b3e6d47c9073d7eef25e6ced4c20cbe49abaaa2e80b01e4e37c1a7c16891810668dd9a6bd88f259bbf8b7a672d37e785c3f2f3aa0b7169b54'),
	(11, 'nome', 'adm@teste.com', '4f22a5b713259a8b3e6d47c9073d7eef25e6ced4c20cbe49abaaa2e80b01e4e37c1a7c16891810668dd9a6bd88f259bbf8b7a672d37e785c3f2f3aa0b7169b54'),
	(12, 'maria eduarda', 'eduardaandrade22@outlook.com', '4f22a5b713259a8b3e6d47c9073d7eef25e6ced4c20cbe49abaaa2e80b01e4e37c1a7c16891810668dd9a6bd88f259bbf8b7a672d37e785c3f2f3aa0b7169b54'),
	(13, 'teste', 'teste@gmail.com', '4f22a5b713259a8b3e6d47c9073d7eef25e6ced4c20cbe49abaaa2e80b01e4e37c1a7c16891810668dd9a6bd88f259bbf8b7a672d37e785c3f2f3aa0b7169b54');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.manutencao
CREATE TABLE IF NOT EXISTS `manutencao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tecnico` int(11) NOT NULL,
  `data` date NOT NULL,
  `tipo` enum('P','C') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tecnico` (`id_tecnico`),
  CONSTRAINT `manutencao_ibfk_1` FOREIGN KEY (`id_tecnico`) REFERENCES `tecnico` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.manutencao: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `manutencao` DISABLE KEYS */;
/*!40000 ALTER TABLE `manutencao` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.missao
CREATE TABLE IF NOT EXISTS `missao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_partida` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data_chegada` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tipo` varchar(50) NOT NULL,
  `id_piloto` int(11) NOT NULL,
  `id_copiloto` int(11) NOT NULL,
  `id_aeronave` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_piloto` (`id_piloto`),
  KEY `id_aeronave` (`id_aeronave`),
  KEY `id_copiloto` (`id_copiloto`),
  CONSTRAINT `missao_ibfk_1` FOREIGN KEY (`id_piloto`) REFERENCES `piloto` (`id`),
  CONSTRAINT `missao_ibfk_2` FOREIGN KEY (`id_aeronave`) REFERENCES `aeronave` (`id`),
  CONSTRAINT `missao_ibfk_3` FOREIGN KEY (`id_copiloto`) REFERENCES `piloto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.missao: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `missao` DISABLE KEYS */;
INSERT INTO `missao` (`id`, `data_partida`, `data_chegada`, `tipo`, `id_piloto`, `id_copiloto`, `id_aeronave`) VALUES
	(4, '1998-10-23 12:20:33', '2018-10-17 12:57:34', 'wewqeqwweweqeqewqeqw', 1, 2, 9),
	(5, '1998-10-23 12:20:33', '1998-10-23 12:20:33', 'wewqeqwweweqeqewqeqw', 1, 2, 9),
	(6, '1998-10-23 12:20:33', '1998-10-23 12:20:33', 'wewqeqwweweqeqewqeqw', 1, 2, 9);
/*!40000 ALTER TABLE `missao` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.piloto
CREATE TABLE IF NOT EXISTS `piloto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(50) NOT NULL,
  `data_nascimento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sexo` enum('M','F') NOT NULL,
  `qualificacao` enum('P','C-P') NOT NULL,
  `ultimo_exame` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `telefone` varchar(22) NOT NULL,
  `endereco` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.piloto: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `piloto` DISABLE KEYS */;
INSERT INTO `piloto` (`id`, `nome`, `cpf`, `data_nascimento`, `sexo`, `qualificacao`, `ultimo_exame`, `telefone`, `endereco`) VALUES
	(1, 'teste2', '12313213213', '1998-10-23 00:00:00', 'M', 'P', '1970-01-01 00:00:00', '12135214651', 'asdasdsadsada'),
	(2, 'testenovo', '12121123351', '1992-10-10 00:00:00', 'F', 'C-P', '1970-01-01 00:00:00', '13213212313', 'dasdasdsadasdsa');
/*!40000 ALTER TABLE `piloto` ENABLE KEYS */;

-- Copiando estrutura para tabela aeronave.tecnico
CREATE TABLE IF NOT EXISTS `tecnico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `data_nascimento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sexo` enum('M','F') NOT NULL,
  `naturalidade` varchar(100) NOT NULL,
  `exame_medico` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `qualificacao` varchar(20) NOT NULL,
  `telefone` varchar(50) NOT NULL,
  `endereco` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Copiando dados para a tabela aeronave.tecnico: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `tecnico` DISABLE KEYS */;
/*!40000 ALTER TABLE `tecnico` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
